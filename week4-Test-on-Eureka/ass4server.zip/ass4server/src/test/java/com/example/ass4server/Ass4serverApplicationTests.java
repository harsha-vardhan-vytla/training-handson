package com.example.ass4server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ass4serverApplicationTests {

	@Test
	void contextLoads() {
	}

}
